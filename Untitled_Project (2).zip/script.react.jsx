import React, { useState } from 'react';

function App() {
  const [view, setView] = useState('list');
  const [selectedAndroid, setSelectedAndroid] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const androidsPerPage = 6;

  // Android data with added purpose/task, work field and organization website
  const androids = [
    {
      id: 1,
      model: "XR-7",
      capabilities: ["Сканирование", "Анализ", "Связь"],
      softwareVersion: "2.3.1",
      lastUpdate: "2025-05-12",
      organization: "MilTech Industries",
      organizationWebsite: "www.miltech.com",
      status: "Активен",
      location: "Сектор 7-B",
      purpose: "Стратегическая разведка и анализ данных в полевых условиях",
      field: "Анализ и разведка"
    },
    {
      id: 2,
      model: "Guardian-9",
      capabilities: ["Охрана", "Распознавание", "Защита"],
      softwareVersion: "3.1.0",
      lastUpdate: "2025-06-03",
      organization: "Defense Robotics",
      organizationWebsite: "www.defenserobotics.org",
      status: "Активен",
      location: "Сектор 3-A",
      purpose: "Обеспечение безопасности объектов и персонала",
      field: "Охрана и безопасность"
    },
    {
      id: 3,
      model: "MediBot-3",
      capabilities: ["Диагностика", "Первая помощь", "Мониторинг"],
      softwareVersion: "4.2.5",
      lastUpdate: "2025-06-15",
      organization: "MediTech Solutions",
      organizationWebsite: "www.meditechsolutions.com",
      status: "Активен",
      location: "Медицинский блок",
      purpose: "Оказание медицинской помощи и мониторинг состояния пациентов",
      field: "Медицина"
    },
    {
      id: 4,
      model: "Psycho-Interface X",
      capabilities: ["Эмоциональный анализ", "Психотерапия", "Общение"],
      softwareVersion: "5.0.2",
      lastUpdate: "2025-05-28",
      organization: "NeuroSystems",
      organizationWebsite: "www.neurosystems.ai",
      status: "Неактивен",
      location: "Техническое обслуживание",
      purpose: "Психологическая поддержка и анализ психического состояния",
      field: "Психология"
    },
    {
      id: 5,
      model: "ChatAssist Pro",
      capabilities: ["Естественный язык", "Информационный поиск", "Помощь"],
      softwareVersion: "6.1.8",
      lastUpdate: "2025-06-10",
      organization: "AI Communications",
      organizationWebsite: "www.aicommunicate.tech",
      status: "Активен",
      location: "Административный сектор",
      purpose: "Обеспечение коммуникационной поддержки и информационной помощи",
      field: "Чат-помощник"
    },
    {
      id: 6,
      model: "Tactical-7",
      capabilities: ["Стратегическое планирование", "Тактический анализ", "Связь"],
      softwareVersion: "3.8.4",
      lastUpdate: "2025-05-20",
      organization: "Military Systems",
      organizationWebsite: "www.militarysystems.gov",
      status: "Активен",
      location: "Командный центр",
      purpose: "Планирование тактических операций и анализ ситуаций",
      field: "Тактическое планирование"
    },
    {
      id: 7,
      model: "NanoTech-12",
      capabilities: ["Нанотехнологии", "Ремонт", "Анализ"],
      softwareVersion: "7.3.2",
      lastUpdate: "2025-06-01",
      organization: "NanoCorp",
      organizationWebsite: "www.nanocorp.innovate",
      status: "Активен",
      location: "Исследовательская лаборатория",
      purpose: "Выполнение микроскопических ремонтных работ и исследований",
      field: "Нанотехнологии"
    },
    {
      id: 8,
      model: "EcoMonitor-5",
      capabilities: ["Экологический мониторинг", "Анализ данных", "Связь"],
      softwareVersion: "2.9.7",
      lastUpdate: "2025-05-18",
      organization: "EcoSystems",
      organizationWebsite: "www.ecosystems.earth",
      status: "Активен",
      location: "Экологический сектор",
      purpose: "Мониторинг экологических параметров и анализ окружающей среды",
      field: "Экологический мониторинг"
    },
    {
      id: 9,
      model: "EduBot-4",
      capabilities: ["Образование", "Преподавание", "Оценка"],
      softwareVersion: "5.6.3",
      lastUpdate: "2025-06-08",
      organization: "EdTech",
      organizationWebsite: "www.edtech.future",
      status: "Активен",
      location: "Образовательный центр",
      purpose: "Предоставление образовательных услуг и оценка знаний",
      field: "Образование"
    },
    {
      id: 10,
      model: "Logistics-3000",
      capabilities: ["Управление запасами", "Планирование", "Координация"],
      softwareVersion: "4.4.0",
      lastUpdate: "2025-06-05",
      organization: "LogiSystems",
      organizationWebsite: "www.logisystems.global",
      status: "Активен",
      location: "Складской комплекс",
      purpose: "Оптимизация логистических процессов и управление запасами",
      field: "Логистика"
    }
  ];

  // Filter androids by search query
  const filteredAndroids = androids.filter(android => {
    const searchLower = searchQuery.toLowerCase();
    return (
      android.model.toLowerCase().includes(searchLower) ||
      android.organization.toLowerCase().includes(searchLower)
    );
  });

  // Calculate number of pages
  const totalPages = Math.ceil(filteredAndroids.length / androidsPerPage);

  // Get androids for current page
  const indexOfLastAndroid = currentPage * androidsPerPage;
  const indexOfFirstAndroid = indexOfLastAndroid - androidsPerPage;
  const currentAndroids = filteredAndroids.slice(indexOfFirstAndroid, indexOfLastAndroid);

  // Function for pagination
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #1a1a2e 0%, #0f3460 100%)',
      color: '#e6e6e6',
      padding: '0',
      fontFamily: "'Roboto', 'Segoe UI', sans-serif",
      position: 'relative',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Top bar */}
      <div style={{
        backgroundColor: '#16213e',
        padding: '15px 20px',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.2)',
        zIndex: 10
      }}>
        <div style={{ display: 'flex', alignItems: 'center' }}>
          <div style={{
            width: '40px',
            height: '40px',
            backgroundColor: '#e94560',
            borderRadius: '50%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            fontSize: '12px',
            fontWeight: 'bold',
            marginRight: '15px'
          }}>
            AI
          </div>
          <h1 style={{ 
            color: '#e94560', 
            margin: '0',
            fontSize: '1.5rem',
            fontWeight: '500'
          }}>
            Android DB
          </h1>
        </div>
        
        <div style={{
          position: 'relative',
          width: '300px'
        }}>
          <input
            type="text"
            placeholder="Поиск по названию или организации..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            style={{
              width: '100%',
              padding: '8px 15px',
              borderRadius: '20px',
              border: '1px solid #0f3460',
              backgroundColor: '#0f3460',
              color: '#e6e6e6',
              fontSize: '14px',
              transition: 'all 0.3s ease',
            }}
            onFocus={(e) => e.target.style.border = '1px solid #e94560'}
            onBlur={(e) => e.target.style.border = '1px solid #0f3460'}
          />
        </div>
      </div>
      
      {/* Main content */}
      {view === 'list' && (
        <div style={{ 
          flex: 1,
          padding: '30px',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
          gap: '25px',
          overflowY: 'auto'
        }}>
          {currentAndroids.map(android => (
            <div 
              key={android.id}
              style={{
                background: 'rgba(16, 33, 65, 0.7)',
                padding: '20px',
                borderRadius: '10px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                border: '1px solid rgba(233, 69, 96, 0.3)',
                position: 'relative',
                overflow: 'hidden'
              }}
              onClick={() => {
                setSelectedAndroid(android);
                setView('details');
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-5px)';
                e.currentTarget.style.boxShadow = '0 10px 20px rgba(233, 69, 96, 0.2)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: '4px',
                backgroundColor: android.status === 'Активен' ? '#4CAF50' : '#f44336'
              }}></div>
              
              <h3 style={{ 
                color: '#e94560', 
                margin: '0 0 15px 0',
                fontWeight: '500',
                fontSize: '1.2rem'
              }}>
                {android.model}
              </h3>
              
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                marginBottom: '15px'
              }}>
                <div>
                  <p style={{ 
                    color: '#aaa', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem'
                  }}>
                    Версия ПО:
                  </p>
                  <p style={{ 
                    color: '#e6e6e6', 
                    margin: '0',
                    fontWeight: '500'
                  }}>
                    {android.softwareVersion}
                  </p>
                </div>
                <div>
                  <p style={{ 
                    color: '#aaa', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem',
                    textAlign: 'right'
                  }}>
                    Обновление:
                  </p>
                  <p style={{ 
                    color: '#e6e6e6', 
                    margin: '0',
                    fontSize: '0.9rem',
                    textAlign: 'right'
                  }}>
                    {android.lastUpdate}
                  </p>
                </div>
              </div>
              
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <p style={{ 
                    color: '#aaa', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem'
                  }}>
                    Организация:
                  </p>
                  <p style={{ 
                    color: '#e6e6e6', 
                    margin: '0',
                    fontSize: '0.9rem'
                  }}>
                    {android.organization}
                  </p>
                </div>
                <div style={{ 
                  padding: '5px 10px',
                  backgroundColor: android.status === 'Активен' ? 'rgba(52, 168, 83, 0.2)' : 'rgba(234, 67, 53, 0.2)',
                  color: android.status === 'Активен' ? '#4CAF50' : '#f44336',
                  borderRadius: '20px',
                  fontSize: '0.8rem',
                  fontWeight: 'bold'
                }}>
                  {android.status}
                </div>
              </div>
            </div>
          ))}
          
          {/* Message if nothing found */}
          {currentAndroids.length === 0 && (
            <div style={{ 
              gridColumn: '1 / -1',
              textAlign: 'center', 
              padding: '40px', 
              color: '#aaa',
              fontSize: '16px'
            }}>
              Ничего не найдено по запросу "{searchQuery}"
            </div>
          )}
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ 
              gridColumn: '1 / -1',
              display: 'flex', 
              justifyContent: 'center', 
              marginTop: '30px',
              gap: '10px'
            }}>
              <button
                onClick={() => paginate(currentPage - 1)}
                disabled={currentPage === 1}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === 1 ? '#2a2a3e' : '#0f3460',
                  color: '#e6e6e6',
                  border: '1px solid #0f3460',
                  borderRadius: '5px',
                  cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
              >
                Назад
              </button>
              
              <span style={{ 
                padding: '8px 15px',
                backgroundColor: '#e94560',
                color: 'white',
                borderRadius: '5px',
                fontWeight: '500'
              }}>
                Страница {currentPage} из {totalPages}
              </span>
              
              <button
                onClick={() => paginate(currentPage + 1)}
                disabled={currentPage === totalPages}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === totalPages ? '#2a2a3e' : '#0f3460',
                  color: '#e6e6e6',
                  border: '1px solid #0f3460',
                  borderRadius: '5px',
                  cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
              >
                Вперед
              </button>
            </div>
          )}
        </div>
      )}

      {view === 'details' && selectedAndroid && (
        <div style={{ 
          flex: 1,
          padding: '30px',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <div style={{ 
            background: 'rgba(16, 33, 65, 0.9)',
            padding: '30px',
            borderRadius: '15px',
            maxWidth: '800px',
            width: '100%',
            position: 'relative',
            border: '1px solid rgba(233, 69, 96, 0.5)'
          }}>
            {/* Status indicator */}
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '5px',
              backgroundColor: selectedAndroid.status === 'Активен' ? '#4CAF50' : '#f44336'
            }}></div>
            
            {/* Close button */}
            <button 
              onClick={() => setView('list')}
              style={{
                position: 'absolute',
                top: '15px',
                right: '15px',
                background: 'none',
                border: 'none',
                color: '#aaa',
                fontSize: '24px',
                cursor: 'pointer',
                padding: '5px',
                lineHeight: '1'
              }}
            >
              ✕
            </button>
            
            <h2 style={{ 
              color: '#e94560', 
              margin: '0 0 30px 0',
              textAlign: 'center',
              fontSize: '1.8rem',
              fontWeight: '500'
            }}>
              Детали: {selectedAndroid.model}
            </h2>
            
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '20px',
              marginBottom: '30px'
            }}>
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Модель:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500'
                }}>
                  {selectedAndroid.model}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Серийный номер:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500'
                }}>
                  {selectedAndroid.id}00{selectedAndroid.id}0
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Версия ПО:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500'
                }}>
                  {selectedAndroid.softwareVersion}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Последнее обновление:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500'
                }}>
                  {selectedAndroid.lastUpdate}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Организация:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500'
                }}>
                  {selectedAndroid.organization}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Сайт организации:
                </p>
                <a 
                  href="#" 
                  style={{ 
                    margin: '0', 
                    color: '#4CAF50',
                    textDecoration: 'none',
                    fontSize: '1.1rem',
                    fontWeight: '500',
                    display: 'block'
                  }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {selectedAndroid.organizationWebsite || "Н/Д"}
                </a>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Состояние:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: selectedAndroid.status === 'Активен' ? '#4CAF50' : '#f44336'
                }}>
                  {selectedAndroid.status}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Сфера работы:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500'
                }}>
                  {selectedAndroid.field}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#e94560', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Цель/задача:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500'
                }}>
                  {selectedAndroid.purpose}
                </p>
              </div>
            </div>
            
            <div style={{ marginBottom: '30px' }}>
              <p style={{ 
                color: '#e94560', 
                margin: '0 0 15px 0',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}>
                Возможности:
              </p>
              <div style={{ 
                display: 'flex',
                flexWrap: 'wrap',
                gap: '10px'
              }}>
                {selectedAndroid.capabilities.map((cap, index) => (
                  <div key={index} style={{ 
                    padding: '8px 15px',
                    backgroundColor: 'rgba(233, 69, 96, 0.2)',
                    borderRadius: '20px',
                    fontSize: '0.9rem'
                  }}>
                    {cap}
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <p style={{ 
                color: '#e94560', 
                margin: '0 0 8px 0',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}>
                Местоположение:
              </p>
              <p style={{ 
                margin: '0',
                fontSize: '1.1rem',
                fontWeight: '500'
              }}>
                {selectedAndroid.location}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;