import React, { useState } from 'react';

function App() {
  const [view, setView] = useState('list');
  const [selectedAndroid, setSelectedAndroid] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const androidsPerPage = 5;

  // Android data with added purpose/task and work field
  const androids = [
    {
      id: 1,
      model: "XR-7",
      capabilities: ["Scanning", "Analysis", "Communication"],
      softwareVersion: "2.3.1",
      lastUpdate: "2025-05-12",
      organization: "MilTech Industries",
      organizationWebsite: "",
      status: "Active",
      location: "Sector 7-B",
      purpose: "Strategic reconnaissance and data analysis in field conditions",
      field: "Analysis and Intelligence"
    },
    {
      id: 2,
      model: "Guardian-9",
      capabilities: ["Security", "Recognition", "Protection"],
      softwareVersion: "3.1.0",
      lastUpdate: "2025-06-03",
      organization: "Defense Robotics",
      organizationWebsite: "",
      status: "Active",
      location: "Sector 3-A",
      purpose: "Ensuring security of facilities and personnel",
      field: "Security and Protection"
    },
    {
      id: 3,
      model: "MediBot-3",
      capabilities: ["Diagnostics", "First Aid", "Monitoring"],
      softwareVersion: "4.2.5",
      lastUpdate: "2025-06-15",
      organization: "MediTech Solutions",
      organizationWebsite: "",
      status: "Active",
      location: "Medical Block",
      purpose: "Providing medical assistance and monitoring patient condition",
      field: "Medicine"
    },
    {
      id: 4,
      model: "Psycho-Interface X",
      capabilities: ["Emotional Analysis", "Psychotherapy", "Communication"],
      softwareVersion: "5.0.2",
      lastUpdate: "2025-05-28",
      organization: "NeuroSystems",
      organizationWebsite: "",
      status: "Inactive",
      location: "Maintenance",
      purpose: "Psychological support and analysis of mental state",
      field: "Psychology"
    },
    {
      id: 5,
      model: "ChatAssist Pro",
      capabilities: ["Natural Language", "Information Search", "Assistance"],
      softwareVersion: "6.1.8",
      lastUpdate: "2025-06-10",
      organization: "AI Communications",
      organizationWebsite: "",
      status: "Active",
      location: "Administrative Sector",
      purpose: "Providing communication support and information assistance",
      field: "Chat Assistant"
    },
    {
      id: 6,
      model: "Tactical-7",
      capabilities: ["Strategic Planning", "Tactical Analysis", "Communication"],
      softwareVersion: "3.8.4",
      lastUpdate: "2025-05-20",
      organization: "Military Systems",
      organizationWebsite: "",
      status: "Active",
      location: "Command Center",
      purpose: "Planning tactical operations and situation analysis",
      field: "Tactical Planning"
    },
    {
      id: 7,
      model: "NanoTech-12",
      capabilities: ["Nanotechnology", "Repair", "Analysis"],
      softwareVersion: "7.3.2",
      lastUpdate: "2025-06-01",
      organization: "NanoCorp",
      organizationWebsite: "",
      status: "Active",
      location: "Research Laboratory",
      purpose: "Performing microscopic repair work and research",
      field: "Nanotechnology"
    },
    {
      id: 8,
      model: "EcoMonitor-5",
      capabilities: ["Environmental Monitoring", "Data Analysis", "Communication"],
      softwareVersion: "2.9.7",
      lastUpdate: "2025-05-18",
      organization: "EcoSystems",
      organizationWebsite: "",
      status: "Active",
      location: "Environmental Sector",
      purpose: "Monitoring environmental parameters and analyzing surroundings",
      field: "Environmental Monitoring"
    },
    {
      id: 9,
      model: "EduBot-4",
      capabilities: ["Education", "Teaching", "Assessment"],
      softwareVersion: "5.6.3",
      lastUpdate: "2025-06-08",
      organization: "EdTech",
      organizationWebsite: "",
      status: "Active",
      location: "Educational Center",
      purpose: "Providing educational services and knowledge assessment",
      field: "Education"
    },
    {
      id: 10,
      model: "Logistics-3000",
      capabilities: ["Inventory Management", "Planning", "Coordination"],
      softwareVersion: "4.4.0",
      lastUpdate: "2025-06-05",
      organization: "LogiSystems",
      organizationWebsite: "",
      status: "Active",
      location: "Warehouse Complex",
      purpose: "Optimizing logistics processes and inventory management",
      field: "Logistics"
    }
  ];

  // Filter androids by search query
  const filteredAndroids = androids.filter(android => {
    const searchLower = searchQuery.toLowerCase();
    return (
      android.model.toLowerCase().includes(searchLower) ||
      android.organization.toLowerCase().includes(searchLower)
    );
  });

  // Calculate number of pages
  const totalPages = Math.ceil(filteredAndroids.length / androidsPerPage);

  // Get androids for current page
  const indexOfLastAndroid = currentPage * androidsPerPage;
  const indexOfFirstAndroid = indexOfLastAndroid - androidsPerPage;
  const currentAndroids = filteredAndroids.slice(indexOfFirstAndroid, indexOfLastAndroid);

  // Function for pagination
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
      color: '#333',
      padding: '20px',
      fontFamily: "'Segoe UI', Tahoma, Geneva, Verdana, sans-serif",
      position: 'relative'
    }}>
      {/* Organization logo in top left corner */}
      <div style={{
        position: 'absolute',
        top: '20px',
        left: '20px',
        width: '60px',
        height: '60px',
        backgroundColor: '#4285f4',
        borderRadius: '50%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '10px', // Small font
        fontWeight: 'bold',
        boxShadow: '0 4px 6px rgba(50, 50, 93, 0.11), 0 1px 3px rgba(0, 0, 0, 0.08)',
        zIndex: 100
      }}>
        (organization logo)
      </div>
      
      <h1 style={{ 
        color: '#4285f4', 
        textAlign: 'center',
        fontWeight: '300',
        letterSpacing: '1px',
        marginBottom: '30px'
      }}>
        ANDROID DATABASE SYSTEM
      </h1>
      
      {view === 'list' && (
        <div style={{ 
          background: 'white',
          padding: '25px',
          borderRadius: '15px',
          marginTop: '20px',
          boxShadow: '0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08)',
          maxWidth: '1000px',
          margin: '20px auto'
        }}>
          <h2 style={{ 
            textAlign: 'center',
            color: '#555',
            fontWeight: '400',
            marginBottom: '25px'
          }}>
            ANDROID DATABASE
          </h2>
          
          {/* Search field */}
          <div style={{ marginBottom: '30px' }}>
            <input
              type="text"
              placeholder="Search by name or organization..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1); // Reset to first page on new search
              }}
              style={{
                width: '100%',
                padding: '12px 15px',
                borderRadius: '8px',
                border: '1px solid #e6e6e6',
                backgroundColor: 'white',
                color: '#333',
                fontSize: '16px',
                transition: 'all 0.3s ease',
                boxSizing: 'border-box',
              }}
              onFocus={(e) => e.target.style.border = '1px solid #4285f4'}
              onBlur={(e) => e.target.style.border = '1px solid #e6e6e6'}
            />
          </div>
          
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: '1fr',
            gap: '15px',
          }}>
            {currentAndroids.map(android => (
              <div 
                key={android.id}
                style={{
                  background: 'white',
                  padding: '20px',
                  borderRadius: '10px',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  boxShadow: '0 4px 6px rgba(50, 50, 93, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08)',
                  transition: 'all 0.3s ease',
                  border: '1px solid #f0f0f0'
                }}
                onClick={() => {
                  setSelectedAndroid(android);
                  setView('details');
                }}
                onMouseOver={(e) => {
                  e.currentTarget.style.transform = 'translateY(-2px)';
                  e.currentTarget.style.boxShadow = '0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08)';
                }}
                onMouseOut={(e) => {
                  e.currentTarget.style.transform = 'translateY(0)';
                  e.currentTarget.style.boxShadow = '0 4px 6px rgba(50, 50, 93, 0.1), 0 1px 3px rgba(0, 0, 0, 0.08)';
                }}
              >
                <div>
                  <h3 style={{ 
                    color: '#4285f4', 
                    margin: '0 0 10px 0',
                    fontWeight: '500'
                  }}>
                    {android.model}
                  </h3>
                  <p style={{ margin: '0', color: '#666' }}>
                    Software Version: {android.softwareVersion}
                  </p>
                </div>
                <div style={{ 
                  color: android.status === 'Active' ? '#34a853' : '#ea4335',
                  fontWeight: 'bold',
                  padding: '5px 10px',
                  borderRadius: '20px',
                  backgroundColor: android.status === 'Active' ? 'rgba(52, 168, 83, 0.1)' : 'rgba(234, 67, 53, 0.1)',
                  fontSize: '14px'
                }}>
                  {android.status}
                </div>
              </div>
            ))}
            
            {/* Message if nothing found */}
            {currentAndroids.length === 0 && (
              <div style={{ 
                textAlign: 'center', 
                padding: '30px', 
                color: '#777',
                fontSize: '16px'
              }}>
                Nothing found for query "{searchQuery}"
              </div>
            )}
          </div>
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ 
              display: 'flex', 
              justifyContent: 'center', 
              marginTop: '30px',
              gap: '10px'
            }}>
              <button
                onClick={() => paginate(currentPage - 1)}
                disabled={currentPage === 1}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === 1 ? '#e0e0e0' : '#f1f3f4',
                  color: '#333',
                  border: 'none',
                  borderRadius: '5px',
                  cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                  fontWeight: '500',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                  transition: 'all 0.2s ease'
                }}
              >
                Back
              </button>
              
              <span style={{ 
                padding: '8px 15px',
                backgroundColor: '#4285f4',
                color: 'white',
                borderRadius: '5px',
                fontWeight: '500',
                boxShadow: '0 2px 4px rgba(66, 133, 244, 0.3)'
              }}>
                Page {currentPage} of {totalPages}
              </span>
              
              <button
                onClick={() => paginate(currentPage + 1)}
                disabled={currentPage === totalPages}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === totalPages ? '#e0e0e0' : '#f1f3f4',
                  color: '#333',
                  border: 'none',
                  borderRadius: '5px',
                  cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                  fontWeight: '500',
                  boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
                  transition: 'all 0.2s ease'
                }}
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}

      {view === 'details' && selectedAndroid && (
        <div style={{ 
          background: 'white',
          padding: '25px',
          borderRadius: '15px',
          marginTop: '20px',
          boxShadow: '0 7px 14px rgba(50, 50, 93, 0.1), 0 3px 6px rgba(0, 0, 0, 0.08)',
          maxWidth: '800px',
          margin: '20px auto',
          position: 'relative'
        }}>
          {/* Organization logo in top left corner on details screen */}
          <div style={{
            position: 'absolute',
            top: '20px',
            left: '20px',
            width: '60px',
            height: '60px',
            backgroundColor: '#4285f4',
            borderRadius: '50%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            fontSize: '10px', // Small font
            fontWeight: 'bold',
            boxShadow: '0 4px 6px rgba(50, 50, 93, 0.11), 0 1px 3px rgba(0, 0, 0, 0.08)',
            zIndex: 100
          }}>
            (organization logo)
          </div>
          
          <h2 style={{ 
            textAlign: 'center',
            color: '#555',
            fontWeight: '400',
            marginBottom: '30px',
            paddingTop: '10px'
          }}>
            ANDROID DETAILS: {selectedAndroid.model}
          </h2>
          
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '25px',
            marginBottom: '20px'
          }}>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Model:</p>
              <p style={{ margin: '0', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
                {selectedAndroid.model}
              </p>
            </div>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Software Version:</p>
              <p style={{ margin: '0', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
                {selectedAndroid.softwareVersion}
              </p>
            </div>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Last Update:</p>
              <p style={{ margin: '0', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
                {selectedAndroid.lastUpdate}
              </p>
            </div>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Organization:</p>
              <p style={{ margin: '0', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
                {selectedAndroid.organization}
              </p>
            </div>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Organization Website:</p>
              <a 
                href="#" 
                style={{ 
                  margin: '0', 
                  padding: '10px', 
                  backgroundColor: '#f8f9fa', 
                  borderRadius: '5px',
                  color: '#34a853',
                  textDecoration: 'none',
                  display: 'block'
                }}
                target="_blank"
                rel="noopener noreferrer"
              >
                {selectedAndroid.organizationWebsite || "N/A"}
              </a>
            </div>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Status:</p>
              <p style={{ 
                margin: '0', 
                padding: '10px', 
                backgroundColor: '#f8f9fa', 
                borderRadius: '5px',
                color: selectedAndroid.status === 'Active' ? '#34a853' : '#ea4335',
                fontWeight: 'bold'
              }}>
                {selectedAndroid.status}
              </p>
            </div>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Field of Work:</p>
              <p style={{ margin: '0', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
                {selectedAndroid.field}
              </p>
            </div>
            <div>
              <p style={{ color: '#4285f4', marginBottom: '5px', fontWeight: '500' }}>Purpose/Task:</p>
              <p style={{ margin: '0', padding: '10px', backgroundColor: '#f8f9fa', borderRadius: '5px' }}>
                {selectedAndroid.purpose}
              </p>
            </div>
          </div>
          
          <div style={{ 
            marginTop: '20px',
            marginBottom: '30px'
          }}>
            <p style={{ color: '#4285f4', marginBottom: '10px', fontWeight: '500' }}>Capabilities:</p>
            <ul style={{ 
              paddingLeft: '20px', 
              margin: '0',
              display: 'grid',
              gridTemplateColumns: 'repeat(3, 1fr)',
              gap: '10px'
            }}>
              {selectedAndroid.capabilities.map((cap, index) => (
                <li key={index} style={{ 
                  margin: '5px 0',
                  padding: '8px 12px',
                  backgroundColor: '#f8f9fa',
                  borderRadius: '20px',
                  listStyleType: 'none',
                  textAlign: 'center',
                  fontSize: '14px'
                }}>
                  {cap}
                </li>
              ))}
            </ul>
          </div>
          
          <div style={{ marginBottom: '30px' }}>
            <p style={{ color: '#4285f4', marginBottom: '10px', fontWeight: '500' }}>Location:</p>
            <p style={{ 
              margin: '0', 
              padding: '15px', 
              backgroundColor: '#f8f9fa', 
              borderRadius: '5px',
              fontSize: '16px'
            }}>
              {selectedAndroid.location}
            </p>
          </div>
          
          <button 
            onClick={() => setView('list')}
            style={{
              backgroundColor: '#4285f4',
              color: 'white',
              border: 'none',
              padding: '12px 25px',
              marginTop: '10px',
              cursor: 'pointer',
              borderRadius: '5px',
              fontWeight: '500',
              display: 'block',
              margin: '0 auto',
              transition: 'background-color 0.3s ease'
            }}
          >
            Back
          </button>
        </div>
      )}
    </div>
  );
}

export default App;