import React, { useState } from 'react';

function App() {
  const [view, setView] = useState('list');
  const [selectedAndroid, setSelectedAndroid] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const androidsPerPage = 6;

  // Android data with added purpose/task, work field
  const androids = [
    {
      id: 1,
      model: "XR-7",
      capabilities: ["Scanning", "Analysis", "Communication"],
      softwareVersion: "2.3.1",
      lastUpdate: "2025-05-12",
      organization: "MilTech Industries",
      organizationWebsite: "",
      status: "Active",
      location: "Sector 7-B",
      purpose: "Strategic reconnaissance and data analysis in field conditions",
      field: "Analysis and Intelligence"
    },
    {
      id: 2,
      model: "Guardian-9",
      capabilities: ["Security", "Recognition", "Protection"],
      softwareVersion: "3.1.0",
      lastUpdate: "2025-06-03",
      organization: "Defense Robotics",
      organizationWebsite: "",
      status: "Active",
      location: "Sector 3-A",
      purpose: "Ensuring security of facilities and personnel",
      field: "Security and Protection"
    },
    {
      id: 3,
      model: "MediBot-3",
      capabilities: ["Diagnostics", "First Aid", "Monitoring"],
      softwareVersion: "4.2.5",
      lastUpdate: "2025-06-15",
      organization: "MediTech Solutions",
      organizationWebsite: "",
      status: "Active",
      location: "Medical Block",
      purpose: "Providing medical assistance and monitoring patient condition",
      field: "Medicine"
    },
    {
      id: 4,
      model: "Psycho-Interface X",
      capabilities: ["Emotional Analysis", "Psychotherapy", "Communication"],
      softwareVersion: "5.0.2",
      lastUpdate: "2025-05-28",
      organization: "NeuroSystems",
      organizationWebsite: "",
      status: "Inactive",
      location: "Maintenance",
      purpose: "Psychological support and mental state analysis",
      field: "Psychology"
    },
    {
      id: 5,
      model: "ChatAssist Pro",
      capabilities: ["Natural Language", "Information Search", "Assistance"],
      softwareVersion: "6.1.8",
      lastUpdate: "2025-06-10",
      organization: "AI Communications",
      organizationWebsite: "",
      status: "Active",
      location: "Administrative Sector",
      purpose: "Providing communication support and information assistance",
      field: "Chat Assistant"
    },
    {
      id: 6,
      model: "Tactical-7",
      capabilities: ["Strategic Planning", "Tactical Analysis", "Communication"],
      softwareVersion: "3.8.4",
      lastUpdate: "2025-05-20",
      organization: "Military Systems",
      organizationWebsite: "",
      status: "Active",
      location: "Command Center",
      purpose: "Planning tactical operations and situation analysis",
      field: "Tactical Planning"
    },
    {
      id: 7,
      model: "NanoTech-12",
      capabilities: ["Nanotechnology", "Repair", "Analysis"],
      softwareVersion: "7.3.2",
      lastUpdate: "2025-06-01",
      organization: "NanoCorp",
      organizationWebsite: "",
      status: "Active",
      location: "Research Laboratory",
      purpose: "Performing microscopic repair work and research",
      field: "Nanotechnology"
    },
    {
      id: 8,
      model: "EcoMonitor-5",
      capabilities: ["Environmental Monitoring", "Data Analysis", "Communication"],
      softwareVersion: "2.9.7",
      lastUpdate: "2025-05-18",
      organization: "EcoSystems",
      organizationWebsite: "",
      status: "Active",
      location: "Environmental Sector",
      purpose: "Monitoring environmental parameters and analyzing surroundings",
      field: "Environmental Monitoring"
    },
    {
      id: 9,
      model: "EduBot-4",
      capabilities: ["Education", "Teaching", "Assessment"],
      softwareVersion: "5.6.3",
      lastUpdate: "2025-06-08",
      organization: "EdTech",
      organizationWebsite: "",
      status: "Active",
      location: "Educational Center",
      purpose: "Providing educational services and knowledge assessment",
      field: "Education"
    },
    {
      id: 10,
      model: "Logistics-3000",
      capabilities: ["Inventory Management", "Planning", "Coordination"],
      softwareVersion: "4.4.0",
      lastUpdate: "2025-06-05",
      organization: "LogiSystems",
      organizationWebsite: "",
      status: "Active",
      location: "Warehouse Complex",
      purpose: "Optimizing logistics processes and inventory management",
      field: "Logistics"
    }
  ];

  // Filter androids by search query
  const filteredAndroids = androids.filter(android => {
    const searchLower = searchQuery.toLowerCase();
    return (
      android.model.toLowerCase().includes(searchLower) ||
      android.organization.toLowerCase().includes(searchLower)
    );
  });

  // Calculate number of pages
  const totalPages = Math.ceil(filteredAndroids.length / androidsPerPage);

  // Get androids for current page
  const indexOfLastAndroid = currentPage * androidsPerPage;
  const indexOfFirstAndroid = indexOfLastAndroid - androidsPerPage;
  const currentAndroids = filteredAndroids.slice(indexOfFirstAndroid, indexOfLastAndroid);

  // Function for pagination
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: '#0a0a14',
      color: '#e6e6e6',
      padding: '0',
      fontFamily: "'Roboto', 'Segoe UI', sans-serif",
      position: 'relative',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Top bar */}
      <div style={{
        backgroundColor: '#131326',
        padding: '15px 20px',
        display: 'flex',
        alignItems: 'center',
        boxShadow: '0 2px 5px rgba(0, 0, 0, 0.2)',
        borderBottom: '1px solid #1f1f3a'
      }}>
        {/* Logo */}
        <div style={{
          width: '50px',
          height: '50px',
          backgroundColor: '#1e88e5',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          fontSize: '20px',
          fontWeight: 'bold',
          color: 'white',
          borderRadius: '3px',
          marginRight: '15px'
        }}>
          ADB
        </div>
        
        <div style={{ flex: 1 }}>
          <h1 style={{ 
            color: '#e0e0e0', 
            margin: '0',
            fontSize: '1.6rem',
            fontWeight: '500',
            letterSpacing: '1px'
          }}>
            ANDROID DATABASE SYSTEM
          </h1>
          <div style={{
            height: '2px',
            background: '#1e88e5',
            marginTop: '5px',
            width: '150px'
          }}></div>
        </div>
        
        {/* Search bar */}
        <div style={{
          position: 'relative',
          width: '300px'
        }}>
          <input
            type="text"
            placeholder="Search by name or organization..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            style={{
              width: '100%',
              padding: '10px 15px',
              border: '1px solid #2d2d44',
              backgroundColor: '#1a1a28',
              color: '#e6e6e6',
              fontSize: '14px',
              fontFamily: "'Roboto', 'Segoe UI', sans-serif",
              borderRadius: '4px',
              transition: 'all 0.3s ease',
            }}
            onFocus={(e) => e.target.style.borderColor = '#1e88e5'}
            onBlur={(e) => e.target.style.borderColor = '#2d2d44'}
          />
          <div style={{
            position: 'absolute',
            top: '50%',
            right: '15px',
            transform: 'translateY(-50%)',
            color: '#888'
          }}>🔍</div>
        </div>
      </div>
      
      {/* Main content */}
      {view === 'list' && (
        <div style={{ 
          flex: 1,
          padding: '25px',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))',
          gap: '20px',
          overflowY: 'auto',
          background: 'linear-gradient(to bottom, #0a0a14, #121220)'
        }}>
          {currentAndroids.map(android => (
            <div 
              key={android.id}
              style={{
                background: '#1a1a28',
                padding: '20px',
                borderRadius: '5px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
                border: '1px solid #2d2d44',
                position: 'relative',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)'
              }}
              onClick={() => {
                setSelectedAndroid(android);
                setView('details');
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-2px)';
                e.currentTarget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.15)';
                e.currentTarget.style.borderColor = '#1e88e5';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 2px 8px rgba(0, 0, 0, 0.1)';
                e.currentTarget.style.borderColor = '#2d2d44';
              }}
            >
              {/* Status indicator */}
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: '4px',
                background: android.status === 'Active' ? 
                  '#4CAF50' : 
                  '#f44336'
              }}></div>
              
              <h3 style={{ 
                color: '#e0e0e0', 
                margin: '0 0 15px 0',
                fontWeight: '500',
                fontSize: '1.2rem'
              }}>
                {android.model}
              </h3>
              
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                marginBottom: '15px'
              }}>
                <div>
                  <p style={{ 
                    color: '#bdbdbd', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem'
                  }}>
                    Software Version:
                  </p>
                  <p style={{ 
                    color: '#ffffff', 
                    margin: '0',
                    fontWeight: '500'
                  }}>
                    {android.softwareVersion}
                  </p>
                </div>
                <div>
                  <p style={{ 
                    color: '#bdbdbd', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem',
                    textAlign: 'right'
                  }}>
                    Last Update:
                  </p>
                  <p style={{ 
                    color: '#ffffff', 
                    margin: '0',
                    fontSize: '0.9rem',
                    textAlign: 'right'
                  }}>
                    {android.lastUpdate}
                  </p>
                </div>
              </div>
              
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <p style={{ 
                    color: '#bdbdbd', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem'
                  }}>
                    Organization:
                  </p>
                  <p style={{ 
                    color: '#ffffff', 
                    margin: '0',
                    fontSize: '0.9rem'
                  }}>
                    {android.organization}
                  </p>
                </div>
                <div style={{ 
                  padding: '4px 10px',
                  backgroundColor: android.status === 'Active' ? 
                    'rgba(76, 175, 80, 0.2)' : 
                    'rgba(244, 67, 54, 0.2)',
                  color: android.status === 'Active' ? '#4CAF50' : '#f44336',
                  borderRadius: '3px',
                  fontSize: '0.8rem',
                  fontWeight: '500'
                }}>
                  {android.status}
                </div>
              </div>
            </div>
          ))}
          
          {/* Message if nothing found */}
          {currentAndroids.length === 0 && (
            <div style={{ 
              gridColumn: '1 / -1',
              textAlign: 'center', 
              padding: '40px', 
              color: '#bdbdbd',
              fontSize: '16px'
            }}>
              Nothing found for query "{searchQuery}"
            </div>
          )}
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ 
              gridColumn: '1 / -1',
              display: 'flex', 
              justifyContent: 'center', 
              marginTop: '30px',
              gap: '10px'
            }}>
              <button
                onClick={() => paginate(currentPage - 1)}
                disabled={currentPage === 1}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === 1 ? '#2d2d44' : '#1a1a28',
                  color: currentPage === 1 ? '#666' : '#e0e0e0',
                  border: '1px solid ' + (currentPage === 1 ? '#333' : '#2d2d44'),
                  borderRadius: '4px',
                  cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                  fontFamily: "'Roboto', 'Segoe UI', sans-serif",
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
              >
                Back
              </button>
              
              <span style={{ 
                padding: '8px 15px',
                backgroundColor: '#1e88e5',
                color: 'white',
                borderRadius: '4px',
                fontFamily: "'Roboto', 'Segoe UI', sans-serif",
                fontWeight: '500'
              }}>
                Page {currentPage} of {totalPages}
              </span>
              
              <button
                onClick={() => paginate(currentPage + 1)}
                disabled={currentPage === totalPages}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === totalPages ? '#2d2d44' : '#1a1a28',
                  color: currentPage === totalPages ? '#666' : '#e0e0e0',
                  border: '1px solid ' + (currentPage === totalPages ? '#333' : '#2d2d44'),
                  borderRadius: '4px',
                  cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                  fontFamily: "'Roboto', 'Segoe UI', sans-serif",
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}

      {view === 'details' && selectedAndroid && (
        <div style={{ 
          flex: 1,
          padding: '25px',
          background: 'linear-gradient(to bottom, #0a0a14, #121220)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}>
          <div style={{ 
            background: '#1a1a28',
            padding: '30px',
            borderRadius: '8px',
            maxWidth: '800px',
            width: '90%',
            position: 'relative',
            border: '1px solid #2d2d44',
            boxShadow: '0 4px 12px rgba(0, 0, 0, 0.2)'
          }}>
            {/* Status indicator */}
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '4px',
              background: selectedAndroid.status === 'Active' ? '#4CAF50' : '#f44336'
            }}></div>
            
            {/* Close button */}
            <button 
              onClick={() => setView('list')}
              style={{
                position: 'absolute',
                top: '15px',
                right: '15px',
                background: '#2d2d44',
                border: '1px solid #444',
                color: '#e0e0e0',
                fontSize: '18px',
                cursor: 'pointer',
                padding: '5px 12px',
                borderRadius: '4px',
                fontFamily: "'Roboto', 'Segoe UI', sans-serif",
                transition: 'all 0.2s ease'
              }}
              onMouseOver={(e) => e.currentTarget.style.backgroundColor = '#333'}
              onMouseOut={(e) => e.currentTarget.style.backgroundColor = '#2d2d44'}
            >
              ×
            </button>
            
            <h2 style={{ 
              color: '#e0e0e0', 
              margin: '0 0 30px 0',
              textAlign: 'center',
              fontSize: '1.6rem',
              fontWeight: '500',
              borderBottom: '1px solid #2d2d44',
              paddingBottom: '15px'
            }}>
              Android Details: {selectedAndroid.model}
            </h2>
            
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '20px',
              marginBottom: '30px'
            }}>
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Model:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.model}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Software Version:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.softwareVersion}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Last Update:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.lastUpdate}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Organization:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.organization}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Organization Website:
                </p>
                <a 
                  href="#" 
                  style={{ 
                    margin: '0', 
                    color: '#1e88e5',
                    textDecoration: 'none',
                    fontSize: '1.1rem',
                    fontWeight: '500',
                    display: 'block'
                  }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {selectedAndroid.organizationWebsite || "N/A"}
                </a>
              </div>
              
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Status:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: selectedAndroid.status === 'Active' ? '#4CAF50' : '#f44336'
                }}>
                  {selectedAndroid.status}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Field of Work:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.field}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#bdbdbd', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Purpose/Task:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.purpose}
                </p>
              </div>
            </div>
            
            <div style={{ marginBottom: '30px' }}>
              <p style={{ 
                color: '#bdbdbd', 
                margin: '0 0 15px 0',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}>
                Capabilities:
              </p>
              <div style={{ 
                display: 'flex',
                flexWrap: 'wrap',
                gap: '10px'
              }}>
                {selectedAndroid.capabilities.map((cap, index) => (
                  <div key={index} style={{ 
                    padding: '8px 15px',
                    backgroundColor: 'rgba(30, 136, 229, 0.1)',
                    border: '1px solid rgba(30, 136, 229, 0.3)',
                    borderRadius: '4px',
                    fontSize: '0.9rem',
                    color: '#1e88e5'
                  }}>
                    {cap}
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <p style={{ 
                color: '#bdbdbd', 
                margin: '0 0 8px 0',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}>
                Location:
              </p>
              <p style={{ 
                margin: '0',
                fontSize: '1.1rem',
                fontWeight: '500',
                color: '#ffffff'
              }}>
                {selectedAndroid.location}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;