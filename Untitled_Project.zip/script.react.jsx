import React, { useState } from 'react';

function App() {
  const [view, setView] = useState('list');
  const [selectedAndroid, setSelectedAndroid] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const androidsPerPage = 5;

  // Android data with added purpose/task and work field
  const androids = [
    {
      id: 1,
      model: "XR-7",
      capabilities: ["Scanning", "Analysis", "Communication"],
      softwareVersion: "2.3.1",
      lastUpdate: "2025-05-12",
      organization: "MilTech Industries",
      organizationWebsite: "",
      status: "Active",
      location: "Sector 7-B",
      purpose: "Strategic reconnaissance and data analysis in field conditions",
      field: "Analysis and Intelligence"
    },
    {
      id: 2,
      model: "Guardian-9",
      capabilities: ["Security", "Recognition", "Protection"],
      softwareVersion: "3.1.0",
      lastUpdate: "2025-06-03",
      organization: "Defense Robotics",
      organizationWebsite: "",
      status: "Active",
      location: "Sector 3-A",
      purpose: "Ensuring security of facilities and personnel",
      field: "Security and Protection"
    },
    {
      id: 3,
      model: "MediBot-3",
      capabilities: ["Diagnostics", "First Aid", "Monitoring"],
      softwareVersion: "4.2.5",
      lastUpdate: "2025-06-15",
      organization: "MediTech Solutions",
      organizationWebsite: "",
      status: "Active",
      location: "Medical Block",
      purpose: "Providing medical assistance and monitoring patient condition",
      field: "Medicine"
    },
    {
      id: 4,
      model: "Psycho-Interface X",
      capabilities: ["Emotional Analysis", "Psychotherapy", "Communication"],
      softwareVersion: "5.0.2",
      lastUpdate: "2025-05-28",
      organization: "NeuroSystems",
      organizationWebsite: "",
      status: "Inactive",
      location: "Maintenance",
      purpose: "Psychological support and analysis of mental state",
      field: "Psychology"
    },
    {
      id: 5,
      model: "ChatAssist Pro",
      capabilities: ["Natural Language", "Information Search", "Assistance"],
      softwareVersion: "6.1.8",
      lastUpdate: "2025-06-10",
      organization: "AI Communications",
      organizationWebsite: "",
      status: "Active",
      location: "Administrative Sector",
      purpose: "Providing communication support and information assistance",
      field: "Chat Assistant"
    },
    {
      id: 6,
      model: "Tactical-7",
      capabilities: ["Strategic Planning", "Tactical Analysis", "Communication"],
      softwareVersion: "3.8.4",
      lastUpdate: "2025-05-20",
      organization: "Military Systems",
      organizationWebsite: "",
      status: "Active",
      location: "Command Center",
      purpose: "Planning tactical operations and situation analysis",
      field: "Tactical Planning"
    },
    {
      id: 7,
      model: "NanoTech-12",
      capabilities: ["Nanotechnology", "Repair", "Analysis"],
      softwareVersion: "7.3.2",
      lastUpdate: "2025-06-01",
      organization: "NanoCorp",
      organizationWebsite: "",
      status: "Active",
      location: "Research Laboratory",
      purpose: "Performing microscopic repair work and research",
      field: "Nanotechnology"
    },
    {
      id: 8,
      model: "EcoMonitor-5",
      capabilities: ["Environmental Monitoring", "Data Analysis", "Communication"],
      softwareVersion: "2.9.7",
      lastUpdate: "2025-05-18",
      organization: "EcoSystems",
      organizationWebsite: "",
      status: "Active",
      location: "Environmental Sector",
      purpose: "Monitoring environmental parameters and analyzing surroundings",
      field: "Environmental Monitoring"
    },
    {
      id: 9,
      model: "EduBot-4",
      capabilities: ["Education", "Teaching", "Assessment"],
      softwareVersion: "5.6.3",
      lastUpdate: "2025-06-08",
      organization: "EdTech",
      organizationWebsite: "",
      status: "Active",
      location: "Educational Center",
      purpose: "Providing educational services and knowledge assessment",
      field: "Education"
    },
    {
      id: 10,
      model: "Logistics-3000",
      capabilities: ["Inventory Management", "Planning", "Coordination"],
      softwareVersion: "4.4.0",
      lastUpdate: "2025-06-05",
      organization: "LogiSystems",
      organizationWebsite: "",
      status: "Active",
      location: "Warehouse Complex",
      purpose: "Optimizing logistics processes and inventory management",
      field: "Logistics"
    }
  ];

  // Filter androids by search query
  const filteredAndroids = androids.filter(android => {
    const searchLower = searchQuery.toLowerCase();
    return (
      android.model.toLowerCase().includes(searchLower) ||
      android.organization.toLowerCase().includes(searchLower)
    );
  });

  // Calculate number of pages
  const totalPages = Math.ceil(filteredAndroids.length / androidsPerPage);

  // Get androids for current page
  const indexOfLastAndroid = currentPage * androidsPerPage;
  const indexOfFirstAndroid = indexOfLastAndroid - androidsPerPage;
  const currentAndroids = filteredAndroids.slice(indexOfFirstAndroid, indexOfLastAndroid);

  // Function for pagination
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: '#1a1a2e', 
      color: '#e6e6e6',
      padding: '20px',
      fontFamily: 'Arial, sans-serif',
      position: 'relative'
    }}>
      {/* Organization logo in top left corner */}
      <div style={{
        position: 'absolute',
        top: '20px',
        left: '20px',
        width: '60px',
        height: '60px',
        backgroundColor: '#e94560',
        borderRadius: '50%',
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        fontSize: '10px', // Small font
        fontWeight: 'bold',
        boxShadow: '0 0 10px rgba(233, 69, 96, 0.5)',
        zIndex: 100
      }}>
        (organization logo)
      </div>
      
      <h1 style={{ color: '#e94560', textAlign: 'center' }}>ANDROID DATABASE SYSTEM</h1>
      
      {view === 'list' && (
        <div style={{ 
          background: '#16213e', 
          padding: '20px', 
          borderRadius: '10px',
          marginTop: '20px'
        }}>
          <h2 style={{ textAlign: 'center' }}>ANDROID DATABASE</h2>
          
          {/* Search field */}
          <div style={{ marginBottom: '20px' }}>
            <input
              type="text"
              placeholder="Search by name or organization..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setCurrentPage(1); // Reset to first page on new search
              }}
              style={{
                width: '100%',
                padding: '10px',
                borderRadius: '5px',
                border: 'none',
                backgroundColor: '#0f3460',
                color: '#e6e6e6',
                fontSize: '16px'
              }}
            />
          </div>
          
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: '1fr',
            gap: '10px',
          }}>
            {currentAndroids.map(android => (
              <div 
                key={android.id}
                style={{
                  background: '#0f3460',
                  padding: '15px',
                  borderRadius: '5px',
                  cursor: 'pointer',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center'
                }}
                onClick={() => {
                  setSelectedAndroid(android);
                  setView('details');
                }}
              >
                <div>
                  <h3 style={{ color: '#e94560', margin: '0 0 10px 0' }}>{android.model}</h3>
                  <p style={{ margin: '0' }}>Software Version: {android.softwareVersion}</p>
                </div>
                <div style={{ 
                  color: android.status === 'Active' ? '#4CAF50' : '#f44336',
                  fontWeight: 'bold' 
                }}>
                  {android.status}
                </div>
              </div>
            ))}
            
            {/* Message if nothing found */}
            {currentAndroids.length === 0 && (
              <div style={{ textAlign: 'center', padding: '20px' }}>
                Nothing found for query "{searchQuery}"
              </div>
            )}
          </div>
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ 
              display: 'flex', 
              justifyContent: 'center', 
              marginTop: '20px',
              gap: '10px'
            }}>
              <button
                onClick={() => paginate(currentPage - 1)}
                disabled={currentPage === 1}
                style={{
                  padding: '5px 10px',
                  backgroundColor: '#0f3460',
                  color: '#e6e6e6',
                  border: 'none',
                  borderRadius: '3px',
                  cursor: currentPage === 1 ? 'not-allowed' : 'pointer'
                }}
              >
                Back
              </button>
              
              <span style={{ 
                padding: '5px 10px',
                backgroundColor: '#e94560',
                color: 'white',
                borderRadius: '3px'
              }}>
                Page {currentPage} of {totalPages}
              </span>
              
              <button
                onClick={() => paginate(currentPage + 1)}
                disabled={currentPage === totalPages}
                style={{
                  padding: '5px 10px',
                  backgroundColor: '#0f3460',
                  color: '#e6e6e6',
                  border: 'none',
                  borderRadius: '3px',
                  cursor: currentPage === totalPages ? 'not-allowed' : 'pointer'
                }}
              >
                Next
              </button>
            </div>
          )}
        </div>
      )}

      {view === 'details' && selectedAndroid && (
        <div style={{ 
          background: '#16213e', 
          padding: '20px', 
          borderRadius: '10px',
          marginTop: '20px'
        }}>
          {/* Organization logo in top left corner on details screen */}
          <div style={{
            position: 'absolute',
            top: '20px',
            left: '20px',
            width: '60px',
            height: '60px',
            backgroundColor: '#e94560',
            borderRadius: '50%',
            display: 'flex',
            justifyContent: 'center',
            alignItems: 'center',
            fontSize: '10px', // Small font
            fontWeight: 'bold',
            boxShadow: '0 0 10px rgba(233, 69, 96, 0.5)',
            zIndex: 100
          }}>
            (organization logo)
          </div>
          
          <h2 style={{ textAlign: 'center' }}>ANDROID DETAILS: {selectedAndroid.model}</h2>
          <div style={{ 
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '15px',
            marginTop: '20px'
          }}>
            <div>
              <p style={{ color: '#e94560' }}>Model:</p>
              <p>{selectedAndroid.model}</p>
            </div>
            <div>
              <p style={{ color: '#e94560' }}>Software Version:</p>
              <p>{selectedAndroid.softwareVersion}</p>
            </div>
            <div>
              <p style={{ color: '#e94560' }}>Last Update:</p>
              <p>{selectedAndroid.lastUpdate}</p>
            </div>
            <div>
              <p style={{ color: '#e94560' }}>Organization:</p>
              <p>{selectedAndroid.organization}</p>
            </div>
            <div>
              <p style={{ color: '#e94560' }}>Organization Website:</p>
              <a 
                href="#" 
                style={{ color: '#4CAF50', textDecoration: 'none' }}
                target="_blank"
                rel="noopener noreferrer"
              >
                {selectedAndroid.organizationWebsite || "N/A"}
              </a>
            </div>
            <div>
              <p style={{ color: '#e94560' }}>Status:</p>
              <p style={{ 
                color: selectedAndroid.status === 'Active' ? '#4CAF50' : '#f44336',
                fontWeight: 'bold' 
              }}>{selectedAndroid.status}</p>
            </div>
            <div>
              <p style={{ color: '#e94560' }}>Field of Work:</p>
              <p>{selectedAndroid.field}</p>
            </div>
            <div>
              <p style={{ color: '#e94560' }}>Purpose/Task:</p>
              <p>{selectedAndroid.purpose}</p>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <p style={{ color: '#e94560' }}>Capabilities:</p>
              <ul style={{ paddingLeft: '20px' }}>
                {selectedAndroid.capabilities.map((cap, index) => (
                  <li key={index}>{cap}</li>
                ))}
              </ul>
            </div>
            <div style={{ gridColumn: '1 / -1' }}>
              <p style={{ color: '#e94560' }}>Location:</p>
              <p>{selectedAndroid.location}</p>
            </div>
          </div>
          <button 
            onClick={() => setView('list')}
            style={{
              backgroundColor: '#e94560',
              color: 'white',
              border: 'none',
              padding: '10px 20px',
              marginTop: '20px',
              cursor: 'pointer',
              borderRadius: '5px'
            }}
          >
            Back
          </button>
        </div>
      )}
    </div>
  );
}

export default App;