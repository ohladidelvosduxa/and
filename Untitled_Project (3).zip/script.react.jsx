import React, { useState } from 'react';

function App() {
  const [view, setView] = useState('list');
  const [selectedAndroid, setSelectedAndroid] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const androidsPerPage = 6;

  // Android data with added purpose/task, work field and organization website
  const androids = [
    {
      id: 1,
      model: "XR-7",
      capabilities: ["Сканирование", "Анализ", "Связь"],
      softwareVersion: "2.3.1",
      lastUpdate: "2025-05-12",
      organization: "MilTech Industries",
      organizationWebsite: "",
      status: "Активен",
      location: "Сектор 7-B",
      purpose: "Стратегическая разведка и анализ данных в полевых условиях",
      field: "Анализ и разведка"
    },
    {
      id: 2,
      model: "Guardian-9",
      capabilities: ["Охрана", "Распознавание", "Защита"],
      softwareVersion: "3.1.0",
      lastUpdate: "2025-06-03",
      organization: "Defense Robotics",
      organizationWebsite: "",
      status: "Активен",
      location: "Сектор 3-A",
      purpose: "Обеспечение безопасности объектов и персонала",
      field: "Охрана и безопасность"
    },
    {
      id: 3,
      model: "MediBot-3",
      capabilities: ["Диагностика", "Первая помощь", "Мониторинг"],
      softwareVersion: "4.2.5",
      lastUpdate: "2025-06-15",
      organization: "MediTech Solutions",
      organizationWebsite: "",
      status: "Активен",
      location: "Медицинский блок",
      purpose: "Оказание медицинской помощи и мониторинг состояния пациентов",
      field: "Медицина"
    },
    {
      id: 4,
      model: "Psycho-Interface X",
      capabilities: ["Эмоциональный анализ", "Психотерапия", "Общение"],
      softwareVersion: "5.0.2",
      lastUpdate: "2025-05-28",
      organization: "NeuroSystems",
      organizationWebsite: "",
      status: "Неактивен",
      location: "Техническое обслуживание",
      purpose: "Психологическая поддержка и анализ психического состояния",
      field: "Психология"
    },
    {
      id: 5,
      model: "ChatAssist Pro",
      capabilities: ["Естественный язык", "Информационный поиск", "Помощь"],
      softwareVersion: "6.1.8",
      lastUpdate: "2025-06-10",
      organization: "AI Communications",
      organizationWebsite: "",
      status: "Активен",
      location: "Административный сектор",
      purpose: "Обеспечение коммуникационной поддержки и информационной помощи",
      field: "Чат-помощник"
    },
    {
      id: 6,
      model: "Tactical-7",
      capabilities: ["Стратегическое планирование", "Тактический анализ", "Связь"],
      softwareVersion: "3.8.4",
      lastUpdate: "2025-05-20",
      organization: "Military Systems",
      organizationWebsite: "",
      status: "Активен",
      location: "Командный центр",
      purpose: "Планирование тактических операций и анализ ситуаций",
      field: "Тактическое планирование"
    },
    {
      id: 7,
      model: "NanoTech-12",
      capabilities: ["Нанотехнологии", "Ремонт", "Анализ"],
      softwareVersion: "7.3.2",
      lastUpdate: "2025-06-01",
      organization: "NanoCorp",
      organizationWebsite: "",
      status: "Активен",
      location: "Исследовательская лаборатория",
      purpose: "Выполнение микроскопических ремонтных работ и исследований",
      field: "Нанотехнологии"
    },
    {
      id: 8,
      model: "EcoMonitor-5",
      capabilities: ["Экологический мониторинг", "Анализ данных", "Связь"],
      softwareVersion: "2.9.7",
      lastUpdate: "2025-05-18",
      organization: "EcoSystems",
      organizationWebsite: "",
      status: "Активен",
      location: "Экологический сектор",
      purpose: "Мониторинг экологических параметров и анализ окружающей среды",
      field: "Экологический мониторинг"
    },
    {
      id: 9,
      model: "EduBot-4",
      capabilities: ["Образование", "Преподавание", "Оценка"],
      softwareVersion: "5.6.3",
      lastUpdate: "2025-06-08",
      organization: "EdTech",
      organizationWebsite: "",
      status: "Активен",
      location: "Образовательный центр",
      purpose: "Предоставление образовательных услуг и оценка знаний",
      field: "Образование"
    },
    {
      id: 10,
      model: "Logistics-3000",
      capabilities: ["Управление запасами", "Планирование", "Координация"],
      softwareVersion: "4.4.0",
      lastUpdate: "2025-06-05",
      organization: "LogiSystems",
      organizationWebsite: "",
      status: "Активен",
      location: "Складской комплекс",
      purpose: "Оптимизация логистических процессов и управление запасами",
      field: "Логистика"
    }
  ];

  // Filter androids by search query
  const filteredAndroids = androids.filter(android => {
    const searchLower = searchQuery.toLowerCase();
    return (
      android.model.toLowerCase().includes(searchLower) ||
      android.organization.toLowerCase().includes(searchLower)
    );
  });

  // Calculate number of pages
  const totalPages = Math.ceil(filteredAndroids.length / androidsPerPage);

  // Get androids for current page
  const indexOfLastAndroid = currentPage * androidsPerPage;
  const indexOfFirstAndroid = indexOfLastAndroid - androidsPerPage;
  const currentAndroids = filteredAndroids.slice(indexOfFirstAndroid, indexOfLastAndroid);

  // Function for pagination
  const paginate = (pageNumber) => {
    if (pageNumber >= 1 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
    }
  };

  return (
    <div style={{ 
      minHeight: '100vh', 
      background: 'linear-gradient(135deg, #050520 0%, #0a0a2a 100%)',
      color: '#e6e6e6',
      padding: '0',
      fontFamily: "'Orbitron', 'Rajdhani', sans-serif",
      position: 'relative',
      display: 'flex',
      flexDirection: 'column'
    }}>
      {/* Neon grid background */}
      <div style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        backgroundImage: 'linear-gradient(rgba(0, 128, 255, 0.05) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 128, 255, 0.05) 1px, transparent 1px)',
        backgroundSize: '20px 20px',
        pointerEvents: 'none',
        zIndex: 1
      }}></div>
      
      {/* Top bar */}
      <div style={{
        backgroundColor: 'rgba(10, 10, 42, 0.8)',
        padding: '15px 20px',
        display: 'flex',
      }}>
        {/* Logo */}
        <div style={{
          width: '60px',
          height: '60px',
          position: 'relative',
          marginRight: '20px'
        }}>
          <div style={{
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            border: '2px solid #00ffff',
            borderRadius: '10px',
            boxShadow: '0 0 10px #00ffff, inset 0 0 10px #00ffff',
            animation: 'pulse 2s infinite alternate',
            zIndex: 2
          }}></div>
          <div style={{
            position: 'absolute',
            top: '10px',
            left: '10px',
            right: '10px',
            bottom: '10px',
            border: '2px solid #ff00ff',
            borderRadius: '5px',
            boxShadow: '0 0 10px #ff00ff, inset 0 0 10px #ff00ff',
            zIndex: 3
          }}></div>
          <div style={{
            position: 'absolute',
            top: '25px',
            left: '25px',
            width: '10px',
            height: '10px',
            backgroundColor: '#00ffff',
            borderRadius: '50%',
            boxShadow: '0 0 5px #00ffff',
            zIndex: 4
          }}></div>
        </div>
        
        <div style={{ flex: 1 }}>
          <h1 style={{ 
            color: '#00ffff', 
            margin: '0',
            fontSize: '1.8rem',
            fontWeight: '700',
            letterSpacing: '2px',
            textShadow: '0 0 10px #00ffff'
          }}>
            CYBER-ANDROID DB
          </h1>
          <div style={{
            height: '3px',
            background: 'linear-gradient(90deg, #00ffff 0%, #ff00ff 100%)',
            marginTop: '5px',
            boxShadow: '0 0 5px #00ffff'
          }}></div>
        </div>
        
        {/* Search bar */}
        <div style={{
          position: 'relative',
          width: '300px',
          marginLeft: '20px'
        }}>
          <input
            type="text"
            placeholder="Поиск по названию или организации..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            style={{
              width: '100%',
              padding: '10px 15px',
              border: '1px solid #00ffff',
              backgroundColor: 'rgba(10, 10, 42, 0.8)',
              color: '#e6e6e6',
              fontSize: '14px',
              fontFamily: "'Orbitron', 'Rajdhani', sans-serif",
              borderRadius: '5px',
              boxShadow: '0 0 10px rgba(0, 255, 255, 0.3)',
              transition: 'all 0.3s ease',
            }}
            onFocus={(e) => {
              e.target.style.boxShadow = '0 0 15px rgba(0, 255, 255, 0.6)';
              e.target.style.borderColor = '#ff00ff';
            }}
            onBlur={(e) => {
              e.target.style.boxShadow = '0 0 10px rgba(0, 255, 255, 0.3)';
              e.target.style.borderColor = '#00ffff';
            }}
          />
          <div style={{
            position: 'absolute',
            top: '50%',
            right: '15px',
            transform: 'translateY(-50%)',
            width: '10px',
            height: '10px',
            border: '2px solid #00ffff',
            borderRadius: '50%',
            boxShadow: '0 0 5px #00ffff'
          }}></div>
        </div>
      </div>
      
      {/* Main content */}
      {view === 'list' && (
        <div style={{ 
          flex: 1,
          padding: '30px',
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))',
          gap: '25px',
          overflowY: 'auto',
          position: 'relative',
          zIndex: 2
        }}>
          {currentAndroids.map(android => (
            <div 
              key={android.id}
              style={{
                background: 'rgba(10, 10, 42, 0.7)',
                padding: '20px',
                borderRadius: '10px',
                cursor: 'pointer',
                transition: 'all 0.3s ease',
                border: '1px solid rgba(0, 255, 255, 0.2)',
                position: 'relative',
                overflow: 'hidden',
                boxShadow: '0 0 15px rgba(0, 255, 255, 0.1)'
              }}
              onClick={() => {
                setSelectedAndroid(android);
                setView('details');
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.transform = 'translateY(-5px)';
                e.currentTarget.style.boxShadow = '0 0 20px rgba(0, 255, 255, 0.3)';
                e.currentTarget.style.borderColor = 'rgba(0, 255, 255, 0.5)';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.transform = 'translateY(0)';
                e.currentTarget.style.boxShadow = '0 0 15px rgba(0, 255, 255, 0.1)';
                e.currentTarget.style.borderColor = 'rgba(0, 255, 255, 0.2)';
              }}
            >
              {/* Status indicator */}
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: '3px',
                background: android.status === 'Активен' ? 
                  'linear-gradient(90deg, #00ff00 0%, #00ffff 100%)' : 
                  'linear-gradient(90deg, #ff0000 0%, #ff00ff 100%)',
                boxShadow: android.status === 'Активен' ? 
                  '0 0 5px #00ff00' : 
                  '0 0 5px #ff0000'
              }}></div>
              
              <h3 style={{ 
                color: '#00ffff', 
                margin: '0 0 15px 0',
                fontWeight: '500',
                fontSize: '1.2rem',
                textShadow: '0 0 5px #00ffff'
              }}>
                {android.model}
              </h3>
              
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                marginBottom: '15px'
              }}>
                <div>
                  <p style={{ 
                    color: '#00ffff', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem'
                  }}>
                    Версия ПО:
                  </p>
                  <p style={{ 
                    color: '#ffffff', 
                    margin: '0',
                    fontWeight: '500'
                  }}>
                    {android.softwareVersion}
                  </p>
                </div>
                <div>
                  <p style={{ 
                    color: '#00ffff', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem',
                    textAlign: 'right'
                  }}>
                    Обновление:
                  </p>
                  <p style={{ 
                    color: '#ffffff', 
                    margin: '0',
                    fontSize: '0.9rem',
                    textAlign: 'right'
                  }}>
                    {android.lastUpdate}
                  </p>
                </div>
              </div>
              
              <div style={{ 
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center'
              }}>
                <div>
                  <p style={{ 
                    color: '#00ffff', 
                    margin: '0 0 5px 0',
                    fontSize: '0.9rem'
                  }}>
                    Организация:
                  </p>
                  <p style={{ 
                    color: '#ffffff', 
                    margin: '0',
                    fontSize: '0.9rem'
                  }}>
                    {android.organization}
                  </p>
                </div>
                <div style={{ 
                  padding: '5px 10px',
                  backgroundColor: android.status === 'Активен' ? 
                    'rgba(0, 255, 0, 0.2)' : 
                    'rgba(255, 0, 0, 0.2)',
                  color: android.status === 'Активен' ? '#00ff00' : '#ff0000',
                  borderRadius: '20px',
                  fontSize: '0.8rem',
                  fontWeight: 'bold',
                  boxShadow: android.status === 'Активен' ? 
                    '0 0 5px #00ff00' : 
                    '0 0 5px #ff0000'
                }}>
                  {android.status}
                </div>
              </div>
            </div>
          ))}
          
          {/* Message if nothing found */}
          {currentAndroids.length === 0 && (
            <div style={{ 
              gridColumn: '1 / -1',
              textAlign: 'center', 
              padding: '40px', 
              color: '#00ffff',
              fontSize: '16px'
            }}>
              Ничего не найдено по запросу "{searchQuery}"
            </div>
          )}
          
          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ 
              gridColumn: '1 / -1',
              display: 'flex', 
              justifyContent: 'center', 
              marginTop: '30px',
              gap: '10px'
            }}>
              <button
                onClick={() => paginate(currentPage - 1)}
                disabled={currentPage === 1}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === 1 ? 'rgba(10, 10, 42, 0.5)' : 'rgba(10, 10, 42, 0.8)',
                  color: currentPage === 1 ? '#555' : '#00ffff',
                  border: '1px solid ' + (currentPage === 1 ? '#333' : '#00ffff'),
                  borderRadius: '5px',
                  cursor: currentPage === 1 ? 'not-allowed' : 'pointer',
                  fontFamily: "'Orbitron', 'Rajdhani', sans-serif",
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
              >
                Назад
              </button>
              
              <span style={{ 
                padding: '8px 15px',
                backgroundColor: 'rgba(0, 255, 255, 0.2)',
                color: '#00ffff',
                border: '1px solid #00ffff',
                borderRadius: '5px',
                fontFamily: "'Orbitron', 'Rajdhani', sans-serif",
                fontWeight: '500',
                textShadow: '0 0 5px #00ffff'
              }}>
                Страница {currentPage} из {totalPages}
              </span>
              
              <button
                onClick={() => paginate(currentPage + 1)}
                disabled={currentPage === totalPages}
                style={{
                  padding: '8px 15px',
                  backgroundColor: currentPage === totalPages ? 'rgba(10, 10, 42, 0.5)' : 'rgba(10, 10, 42, 0.8)',
                  color: currentPage === totalPages ? '#555' : '#00ffff',
                  border: '1px solid ' + (currentPage === totalPages ? '#333' : '#00ffff'),
                  borderRadius: '5px',
                  cursor: currentPage === totalPages ? 'not-allowed' : 'pointer',
                  fontFamily: "'Orbitron', 'Rajdhani', sans-serif",
                  fontWeight: '500',
                  transition: 'all 0.2s ease'
                }}
              >
                Вперед
              </button>
            </div>
          )}
        </div>
      )}

      {view === 'details' && selectedAndroid && (
        <div style={{ 
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center',
          zIndex: 100
        }}>
          <div style={{ 
            background: 'rgba(10, 10, 42, 0.95)',
            padding: '30px',
            borderRadius: '15px',
            maxWidth: '800px',
            width: '90%',
            position: 'relative',
            border: '1px solid rgba(0, 255, 255, 0.3)',
            boxShadow: '0 0 30px rgba(0, 255, 255, 0.2)',
            maxHeight: '90vh',
            overflowY: 'auto'
          }}>
            {/* Status indicator */}
            <div style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              height: '5px',
              background: selectedAndroid.status === 'Активен' ? 
                'linear-gradient(90deg, #00ff00 0%, #00ffff 100%)' : 
                'linear-gradient(90deg, #ff0000 0%, #ff00ff 100%)',
              boxShadow: selectedAndroid.status === 'Активен' ? 
                '0 0 8px #00ff00' : 
                '0 0 8px #ff0000'
            }}></div>
            
            {/* Close button */}
            <button 
              onClick={() => setView('list')}
              style={{
                position: 'absolute',
                top: '15px',
                right: '15px',
                background: 'rgba(0, 0, 0, 0.5)',
                border: '1px solid #00ffff',
                color: '#00ffff',
                fontSize: '20px',
                cursor: 'pointer',
                padding: '5px 10px',
                borderRadius: '5px',
                fontFamily: "'Orbitron', 'Rajdhani', sans-serif",
                transition: 'all 0.3s ease'
              }}
              onMouseOver={(e) => {
                e.currentTarget.style.backgroundColor = 'rgba(0, 255, 255, 0.2)';
                e.currentTarget.style.boxShadow = '0 0 10px #00ffff';
              }}
              onMouseOut={(e) => {
                e.currentTarget.style.backgroundColor = 'rgba(0, 0, 0, 0.5)';
                e.currentTarget.style.boxShadow = 'none';
              }}
            >
              ✕
            </button>
            
            <h2 style={{ 
              color: '#00ffff', 
              margin: '0 0 30px 0',
              textAlign: 'center',
              fontSize: '1.8rem',
              fontWeight: '500',
              textShadow: '0 0 8px #00ffff'
            }}>
              Детали: {selectedAndroid.model}
            </h2>
            
            <div style={{ 
              display: 'grid',
              gridTemplateColumns: '1fr 1fr',
              gap: '20px',
              marginBottom: '30px'
            }}>
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Модель:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.model}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Серийный номер:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.id}00{selectedAndroid.id}0
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Версия ПО:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.softwareVersion}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Последнее обновление:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.lastUpdate}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Организация:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.organization}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Сайт организации:
                </p>
                <a 
                  href="#" 
                  style={{ 
                    margin: '0', 
                    color: '#00ffff',
                    textDecoration: 'underline',
                    fontSize: '1.1rem',
                    fontWeight: '500',
                    display: 'block'
                  }}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  {selectedAndroid.organizationWebsite || "Н/Д"}
                </a>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Состояние:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: selectedAndroid.status === 'Активен' ? '#00ff00' : '#ff0000',
                  textShadow: selectedAndroid.status === 'Активен' ? 
                    '0 0 5px #00ff00' : 
                    '0 0 5px #ff0000'
                }}>
                  {selectedAndroid.status}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Сфера работы:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.field}
                </p>
              </div>
              
              <div>
                <p style={{ 
                  color: '#00ffff', 
                  margin: '0 0 8px 0',
                  fontSize: '0.9rem',
                  textTransform: 'uppercase',
                  letterSpacing: '1px'
                }}>
                  Цель/задача:
                </p>
                <p style={{ 
                  margin: '0',
                  fontSize: '1.1rem',
                  fontWeight: '500',
                  color: '#ffffff'
                }}>
                  {selectedAndroid.purpose}
                </p>
              </div>
            </div>
            
            <div style={{ marginBottom: '30px' }}>
              <p style={{ 
                color: '#00ffff', 
                margin: '0 0 15px 0',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}>
                Возможности:
              </p>
              <div style={{ 
                display: 'flex',
                flexWrap: 'wrap',
                gap: '10px'
              }}>
                {selectedAndroid.capabilities.map((cap, index) => (
                  <div key={index} style={{ 
                    padding: '8px 15px',
                    backgroundColor: 'rgba(0, 255, 255, 0.2)',
                    border: '1px solid rgba(0, 255, 255, 0.3)',
                    borderRadius: '20px',
                    fontSize: '0.9rem',
                    color: '#00ffff',
                    boxShadow: '0 0 5px rgba(0, 255, 255, 0.2)'
                  }}>
                    {cap}
                  </div>
                ))}
              </div>
            </div>
            
            <div>
              <p style={{ 
                color: '#00ffff', 
                margin: '0 0 8px 0',
                fontSize: '0.9rem',
                textTransform: 'uppercase',
                letterSpacing: '1px'
              }}>
                Местоположение:
              </p>
              <p style={{ 
                margin: '0',
                fontSize: '1.1rem',
                fontWeight: '500',
                color: '#ffffff'
              }}>
                {selectedAndroid.location}
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;